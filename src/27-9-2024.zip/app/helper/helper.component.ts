import { Component } from '@angular/core';

@Component({
  selector: 'app-helper',
  standalone: true,
  imports: [],
  templateUrl: './helper.component.html',
  styleUrl: './helper.component.css'
})
export class HelperComponent {

}
